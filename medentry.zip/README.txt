If you have some issues with installing npm packages please try to write this command and reinstall this package:

npm install webp-converter@2.2.3 --save-dev


!!!! IMPORTANT

for switching between logged user and not, use class logged.
